// prompt-sync.d.ts
declare module 'prompt-sync' {
    function promptSync(): (text: string) => string;
    export default promptSync;
}